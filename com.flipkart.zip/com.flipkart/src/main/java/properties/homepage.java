package properties;

public interface homepage {
	
	String PAGE_TITLE="//img[@title='Flipkart']";
	String SEARCH_TEXTBOX="//input [@placeholder='Search for products, brands and more']";
	String PRODUCT_CATEGORY="(//div[text()='in Mobiles'])[1]";
	
	String CLOSE_ICON="//button[@class='_2KpZ6l _2doB4z']";
	

}
